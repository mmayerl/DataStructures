﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoDatMockExam {
    internal class DivExpression : BinaryExpression {
        public override double Calculate() {
            return Left.Calculate() / Right.Calculate();
        }

        public override string ToString() {
            return $"({Left} / {Right})";
        }
    }
}
