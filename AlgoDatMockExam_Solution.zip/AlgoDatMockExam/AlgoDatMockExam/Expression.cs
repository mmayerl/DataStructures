﻿namespace AlgoDatMockExam;

abstract class Expression {
    public abstract override string ToString();

    public abstract double Calculate();
}
