﻿namespace AlgoDatMockExam;

class Program {
    static void Main(string[] args) {
        TestExpressions();
        TestDoorSwitches();
    }

    private static void TestExpressions() {
        // Build a test expression.
        var exp = new MulExpression {
            Left = new AddExpression {
                Left = new LiteralExpression(12.5),
                Right = new SubExpression { 
                    Left = new LiteralExpression(10),
                    Right = new LiteralExpression(4.5)
                }
            },
            Right = new DivExpression {
                Left = new LiteralExpression(2.0),
                Right = new AddExpression {
                    Left = new LiteralExpression(5.0),
                    Right = new LiteralExpression(2.5)
                }
            },
        };

        // Test:
        Console.WriteLine(exp + " = " + exp.Calculate());
    }

    private static void TestDoorSwitches() {
        // Create switches.
        var doorSwitch1 = new DoorSwitch("Door Switch #1");
        var doorSwitch2 = new DoorSwitch("Door Switch #2");
        var doorSwitch3 = new DoorSwitch("Door Switch #3");
        var doorSwitch4 = new DoorSwitch("Door Switch #4");
        var doorSwitch5 = new DoorSwitch("Door Switch #5");

        // Create doors.
        var door1 = new Door("Door #1", true, [ doorSwitch1, doorSwitch2 ]);
        var door2 = new Door("Door #2", false, [ doorSwitch3, doorSwitch4, doorSwitch5 ]);
        var door3 = new Door("Door #3", true, [ doorSwitch1, doorSwitch4 ]);

        // Run some logic.
        doorSwitch1.PushSwitch();
        doorSwitch5.PushSwitch();
        doorSwitch2.PushSwitch();
        doorSwitch4.PushSwitch();
        doorSwitch5.PushSwitch();

        // Check states at the end.
        Console.WriteLine($"{door1.Name}: {(door1.IsOpen ? "open" : "closed")}");
        Console.WriteLine($"{door2.Name}: {(door2.IsOpen ? "open" : "closed")}");
        Console.WriteLine($"{door2.Name}: {(door2.IsOpen ? "open" : "closed")}");
    }
}
