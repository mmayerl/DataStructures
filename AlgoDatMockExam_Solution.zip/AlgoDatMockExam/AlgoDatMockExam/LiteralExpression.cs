﻿namespace AlgoDatMockExam {
    internal class LiteralExpression : Expression {
        public double Value { get; set; }

        public LiteralExpression(double value) {
            Value = value;
        }

        public override string ToString() {
            return Value.ToString();
        }

        public override double Calculate() {
            return Value;
        }
    }
}
