﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoDatMockExam {
    internal class DoorSwitch {
        public string Name {  get; set; }
        public event EventHandler<OnDoorSwitchPushedEventArgs> OnDoorSwitchPushed;

        public DoorSwitch(string name) {
            this.Name = name;
        }

        public void PushSwitch() {
            this.OnDoorSwitchPushed(this, new OnDoorSwitchPushedEventArgs(this.Name));
        }
    }
}
