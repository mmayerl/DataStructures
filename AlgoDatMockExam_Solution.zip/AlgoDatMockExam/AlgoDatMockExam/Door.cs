﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AlgoDatMockExam {
    internal class Door {
        public string Name {  get; set; }
        public bool IsOpen { get; set; }

        public Door(string name, bool isOpen, DoorSwitch[] connectedSwitches) {
            Name = name;
            IsOpen = isOpen;

            foreach (DoorSwitch sw in connectedSwitches) {
                sw.OnDoorSwitchPushed += Switch_OnDoorSwitchPushed;
            }
        }

        private void Switch_OnDoorSwitchPushed(object? sender, OnDoorSwitchPushedEventArgs e) {
            Console.WriteLine($"Door {this.Name} was {(this.IsOpen ? "closed" : "opened")} by {e.PushedSwitchName}");
            this.IsOpen = !this.IsOpen;
        }
    }
}
